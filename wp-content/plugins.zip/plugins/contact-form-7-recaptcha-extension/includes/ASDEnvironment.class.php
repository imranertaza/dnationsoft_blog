<?php

if (!class_exists('ASDEnvironment')) {
    class ASDEnvironment {
        const WordPress = 1; // regular wordpress
        const WordPressMU = 2; // wordpress mu
        const WordPressMS = 3; // wordpress multi-site
    }
}

?>